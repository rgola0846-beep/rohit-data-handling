# Student Academic Performance Analytics Dashboard

## Files
- `student_academic_performance.ipynb`: complete Google Colab/Jupyter notebook
- `student_performance_dashboard.html`: interactive Plotly dashboard (standalone)
- `student_performance_raw.csv`: 100 synthetic sample records including intentional quality issues
- `student_performance_clean.csv`: cleaned dataset
- `reflection.txt`: required one-paragraph reflection
- `program_performance_summary.csv`: groupby summary

## Run in Google Colab
1. Upload `student_academic_performance.ipynb` to Google Colab.
2. Select Runtime > Run all.
3. The notebook creates the dashboard HTML and output CSV files in the Colab working directory.
4. Download the generated files from the Files panel.

## Run locally
Install notebook dependencies with:
`pip install pandas numpy matplotlib seaborn plotly scikit-learn mlflow`
Then open the notebook in Jupyter and Run All.

## Dataset note
The 100 records are synthetic sample data for an academic demonstration, not actual student records. Replace with institution-approved anonymized data for real analysis.
